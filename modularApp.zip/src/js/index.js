class App {
    constructor () {
        this.initApp();
    }

    initApp () {
      // Start application
    }
}

new App();
