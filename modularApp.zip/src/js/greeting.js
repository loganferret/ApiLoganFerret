/*
* Objectif : déterminer un "salut" en fonction de l'heure et l'afficher
*
* Étapes :
* 1- Créer une référence vers les éléments du DOM qu'on va utiliser
* 2- Récupérer une salutation en fonction de l'heure
* 3- Récupérer une valeur aléatoire à partir d'un tableau
* 4- Afficher le résultat
* */
