/*
* Objectif : récupérer une image aléatoire à partir d'une API et l'afficher
*
* Étapes :
* 1- Créer une référence vers les éléments du DOM qu'on va utiliser
* 2- Récupérer une image de façon asynchrone à partir de l'API d'Unsplash (https://source.unsplash.com/)
* 3- Définir l'image comme fond
* */

export class Background {
    constructor () {
        this.initEls();
        this.initEvents();
    }

    initEls () {
        // Éléments non-jQuery
        this.els = {};

        // Éléments jQuery
        this.$els = {};
        
        // Autres éléments
        this.url = 'https://source.unsplash.com/collection';
    }

    initEvents () {

    }
}
